package com.mrdev.androidtestassesment.other;


/**
 * Changes has been done on 21 March 2024 by MrDev(Mahesh)
 *
 * */
class Cons {
    companion object {
        const val BASE_URL = "https://jsonplaceholder.typicode.com/"
    }
}