package com.mrdev.androidtestassesment.base;

public interface LogoutInterface {
    public void logoutFromApp(boolean shouldLogout);
}
